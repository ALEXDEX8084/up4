﻿using Converencia.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Converencia.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddModerators.xaml
    /// </summary>
    public partial class AddModerators : Page
    {
        private Moderators _currentModerators = new Moderators();
        string imgLoc = "пусто";
        public AddModerators(Moderators selectedModerators)
        {
            InitializeComponent();
            CMBPol.ItemsSource = ConferenceEntities.GetContext().Pol.ToList();
            CMBPol.SelectedValuePath = "IDPol";
            CMBPol.DisplayMemberPath = "NamePol";
            CMBCountry.ItemsSource = ConferenceEntities.GetContext().Country.ToList();
            CMBCountry.SelectedValuePath = "IDCountry";
            CMBCountry.DisplayMemberPath = "NameCountry";
            CMBDirection.ItemsSource = ConferenceEntities.GetContext().Direction.ToList();
            CMBDirection.SelectedValuePath = "IDDirection";
            CMBDirection.DisplayMemberPath = "NameDirection";
            CMBEvent.ItemsSource = ConferenceEntities.GetContext().Event.ToList();
            CMBEvent.SelectedValuePath = "IDEvent";
            CMBEvent.DisplayMemberPath = "NameEvent";

            if (selectedModerators != null)
            {
                _currentModerators = selectedModerators;
            }
            DataContext = _currentModerators;
        }
        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentModerators.FIO)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(_currentModerators.Email)) error.AppendLine("Укажите логин");
            if (string.IsNullOrWhiteSpace(_currentModerators.DateOfBirth.ToString())) error.AppendLine("Укажите дату рождения");
            if (string.IsNullOrWhiteSpace(_currentModerators.Phone)) error.AppendLine("Укажите номер телефона");
            if (string.IsNullOrWhiteSpace(_currentModerators.Pasword)) error.AppendLine("Укажите пароль");

            if (string.IsNullOrWhiteSpace(_currentModerators.IDPol.ToString())) error.AppendLine("Укажите пол");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentModerators.IDModerators == 0)
            {
                ConferenceEntities.GetContext().Moderators.Add(_currentModerators);
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        string filename = imgLoc.Substring(imgLoc.LastIndexOf('\\') + 1);
                        _currentModerators.Photo = String.Concat("/Photo/", filename);
                    }
                    if (imgLoc == "пусто") _currentModerators.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ModeratorsList());
                    MessageBox.Show("Новый модератор успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentModerators.Photo = imgLoc;
                    }
                    if (imgLoc == "пусто") _currentModerators.Photo = null;

                    ConferenceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new ModeratorsList());
                    MessageBox.Show("Модератор успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ModeratorsList());
        }
        private void PhotoLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*",
                    Title = "Выберите фото/изображение организатора"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageModerators.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
