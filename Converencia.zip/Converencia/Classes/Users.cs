﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Converencia.Classes
{
	internal class Users
	{
		public static Users GetUsers { get; set; }
		public int ID { get; set; }
		public string FIO { get; set; }
		public string Email { get; set; }
		public int IDCountry { get; set; }
		public string Phone { get; set; }
		public string Pasword { get; set; }
		public int IDPol { get; set; }

		public Users(Participants participants)
		{
			ID = participants.IDParticipants;
			FIO = participants.FIO;
			Email = participants.Email;
			IDCountry = participants.IDCountry;
			Phone = participants.Phone;
			Pasword = participants.Pasword;
			IDPol = participants.IDPol;
			GetUsers = this;
		}
		public Users(Moderators moderators)
		{
			ID = moderators.IDModerators;
			FIO = moderators.FIO;
			Email = moderators.Email;
			IDCountry = moderators.IDCountry;
			Phone = moderators.Phone;
			Pasword = moderators.Pasword;
			IDPol = moderators.IDPol;
			GetUsers = this;

		}
		public Users(Organizers organizers)
		{
			ID = organizers.IDOrganizers;
			FIO = organizers.FIO;
			Email = organizers.Email;
			IDCountry = organizers.IDCountry;
			Phone = organizers.Phone;
			Pasword = organizers.Pasword;
			IDPol = organizers.IDPol;
			GetUsers = this;

		}
		public Users(Jury jury)
		{
			ID = jury.IDJury;
			FIO = jury.FIO;
			Email = jury.Email;
			IDCountry = jury.IDCountry;
			Phone = jury.Phone;
			Pasword = jury.Pasword;
			IDPol = jury.IDPol;
			GetUsers = this;

		}
	}
}
